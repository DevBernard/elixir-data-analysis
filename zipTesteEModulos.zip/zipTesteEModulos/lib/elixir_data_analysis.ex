defmodule ElixirDataAnalysis do
  def get_json_content(filename \\ "users-data.json") do
    filename
    |> File.read!
    |> Jason.decode!
  end


  def get_json_metric_list(content, metric) when metric == "created_at" do
    now = DateTime.utc_now()
    content
    |> Enum.map(&DateTime.diff(elem(DateTime.from_iso8601(&1[metric]),1), now) * -1)
  end
  def get_json_metric_list(content, metric) do
    content
    |> Enum.map(& &1[metric])
  end

  def apply_analysis(list, metric) do
    {min, max} = Enum.min_max(list)
    %{
      :metric => metric,
      :min => min,
      :max => max,
      :avg => Aggregators.avg(list),
      :median => Aggregators.median(list),
      :std => Aggregators.std_deviation(list),
    }
  end

  def print_analysis(map) do
    IO.puts("#{map.metric},#{map.min},#{map.max},#{map.avg},#{map.median},#{map.std}")
  end

  def print_analysis() do
    IO.puts("metric,min,max,avg,median,std")
  end

  def generate_analysis(metric) do
    content = get_json_content()
    list = get_json_metric_list(content, metric)
    # IO.puts(hd(list))
    applied = apply_analysis(list, metric)
    print_analysis(applied)
  end
end

metrics = ["followers_count","following_count","created_at"]
ElixirDataAnalysis.print_analysis()
metrics
|> Enum.each(&ElixirDataAnalysis.generate_analysis/1)
