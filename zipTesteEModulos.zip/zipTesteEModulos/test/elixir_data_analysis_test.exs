defmodule ElixirDataAnalysisTest do
  use ExUnit.Case


end
